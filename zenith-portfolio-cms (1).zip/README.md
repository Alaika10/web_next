
# Zenith | Full Next.js Portfolio & CMS

Proyek ini adalah sistem portofolio pribadi 100% Next.js dengan fitur manajemen konten (CRUD) dan kecerdasan buatan Gemini.

## 🛠️ Persiapan & Instalasi

1. **Buat Proyek Next.js Baru**:
   Jika Anda memulai dari nol di komputer lokal:
   ```bash
   npx create-next-app@latest my-portfolio --typescript --tailwind --eslint
   ```

2. **Masuk ke Direktori**:
   ```bash
   cd my-portfolio
   ```

3. **Instal Dependensi**:
   ```bash
   npm install @supabase/supabase-js @google/genai lucide-react recharts clsx tailwind-merge
   ```

4. **Konfigurasi Environment (`.env.local`)**:
   Dapatkan API Key dari [Google AI Studio](https://aistudio.google.com/) dan [Supabase](https://supabase.com/).
   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://your-id.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
   API_KEY=your-gemini-api-key
   ```

5. **Struktur Direktori**:
   Pastikan folder `app/`, `components/`, `lib/`, dan `services/` berada di dalam root atau folder `src/`.

6. **Jalankan Developer Server**:
   ```bash
   npm run dev
   ```

## 🚀 Fitur Utama
- **CRUD Blog**: Tulis, edit, dan hapus artikel dengan dukungan Markdown.
- **CRUD Project**: Kelola portofolio karya Anda secara dinamis.
- **AI Content**: Gunakan Gemini Pro untuk membuat draf blog otomatis.
- **AI Refinement**: Gunakan Gemini Flash untuk memoles deskripsi proyek.
- **Responsive Admin**: Dashboard admin yang dioptimalkan untuk mobile.
